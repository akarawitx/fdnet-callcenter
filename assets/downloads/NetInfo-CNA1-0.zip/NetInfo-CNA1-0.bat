@echo off
@chcp 65001 >nul
@echo กำลังตรวจสอบข้อมูลระบบและเครือข่าย กรุณารอสักครู่...
@findstr /v "^@" "%~f0" | powershell -NoProfile -ExecutionPolicy Bypass -Command -
@exit /b

# ===================================================
# Script Check Net พัฒนาโดย กอง CNA v. 1.0
# ===================================================

# 1. ข้อมูลเครื่องและการ Join Domain
$cs = Get-CimInstance Win32_ComputerSystem
$compName     = $env:COMPUTERNAME
$domainName   = $cs.Domain
$isDomainJoin = if ($cs.PartOfDomain) { "Join Domain แล้ว ($domainName)" } else { "ไม่ได้ Join Domain (Workgroup: $domainName)" }
$domainBadgeClass = if ($cs.PartOfDomain) { "badge-domain-yes" } else { "badge-domain-no" }

# 2. ข้อมูล Network Adapter หลัก
$adapter = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null } | Select-Object -First 1
if (-not $adapter) {
    $adapter = Get-NetIPConfiguration | Where-Object { $_.NetIPv4Interface.InterfaceAlias -notlike "*Loopback*" -and $_.IPv4Address -ne $null } | Select-Object -First 1
}

$ipAddress   = if ($adapter.IPv4Address) { ($adapter.IPv4Address.IPAddress) -join ", " } else { "ไม่พบ IP" }
$gateway     = if ($adapter.IPv4DefaultGateway) { ($adapter.IPv4DefaultGateway.NextHop) -join ", " } else { "ไม่มี Gateway" }
$dnsServers  = if ($adapter.DNSServer) { ($adapter.DNSServer.ServerAddresses) -join ", " } else { "ไม่พบ DNS" }
$adapterName = if ($adapter) { $adapter.InterfaceAlias } else { "Unknown" }
$checkTime   = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")

# 3. ดึงตาราง IP Routing
$routes = Get-NetRoute -AddressFamily IPv4 | Sort-Object DestinationPrefix | Select-Object DestinationPrefix, NextHop, InterfaceAlias, RouteMetric

$routeRows = ""
foreach ($r in $routes) {
    $isDefault = if ($r.DestinationPrefix -eq "0.0.0.0/0") { "style='background-color: #ecfdf5; font-weight: bold;'" } else { "" }
    $routeRows += "<tr $isDefault><td><code>$($r.DestinationPrefix)</code></td><td><code>$($r.NextHop)</code></td><td>$($r.InterfaceAlias)</td><td>$($r.RouteMetric)</td></tr>`n"
}

# 4. สร้างหน้า Web Dashboard
$html = @"
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สรุปผลการเชื่อมต่อเครือข่าย (CNA Network Status v. 1.0)</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f8fafc; color: #1e293b; padding: 24px; }
        .container { max-width: 950px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px; }
        h1 { font-size: 22px; color: #0f172a; }
        .timestamp { font-size: 13px; color: #64748b; }
        
        /* Grid การ์ดแสดงผล */
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 20px; }
        .card { background: #ffffff; border-radius: 10px; padding: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); border-top: 4px solid #3b82f6; }
        .card.comp { border-top-color: #0284c7; }
        .card.domain { border-top-color: #6366f1; }
        .card.gw { border-top-color: #10b981; }
        .card.dns { border-top-color: #8b5cf6; }
        .card.nic { border-top-color: #f59e0b; }
        .card-label { font-size: 11px; font-weight: 600; text-transform: uppercase; color: #64748b; margin-bottom: 6px; }
        .card-value { font-size: 16px; font-weight: 700; color: #0f172a; word-break: break-all; }
        
        .badge-domain-yes { color: #15803d; font-weight: 700; }
        .badge-domain-no { color: #b45309; font-weight: 700; }

        /* กล่องแจ้งงานและปุ่มคัดลอก */
        .action-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; gap: 15px; }
        .copy-btn { background: #2563eb; color: white; border: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; transition: all 0.2s ease; white-space: nowrap; }
        .copy-btn:hover { background: #1d4ed8; }
        .copy-btn.copied { background: #16a34a !important; }

        /* ตาราง Route */
        .table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .search-input { padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; width: 260px; font-size: 13px; }
        .table-box { background: #ffffff; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); overflow-x: auto; max-height: 380px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
        thead { position: sticky; top: 0; background: #f1f5f9; z-index: 1; }
        th { padding: 10px 14px; font-weight: 600; color: #475569; border-bottom: 1px solid #cbd5e1; }
        td { padding: 10px 14px; border-bottom: 1px solid #f1f5f9; }
        code { background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: Consolas, monospace; font-size: 12px; color: #0369a1; }
        .tip { font-size: 12px; color: #64748b; margin-top: 8px; }

        /* เครดิตท้ายหน้า */
        .cna-footer { margin-top: 35px; padding-top: 15px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 13px; color: #64748b; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1>รายงานสถานะเครื่องและเครือข่ายคอมพิวเตอร์</h1>
                <div class="timestamp">เวลาที่ตรวจสอบ: <span id="disp-time">$checkTime</span></div>
            </div>
        </div>

        <div class="grid">
            <div class="card comp">
                <div class="card-label">ชื่อเครื่อง (Computer Name)</div>
                <div class="card-value" id="disp-comp">$compName</div>
            </div>
            <div class="card domain">
                <div class="card-label">สถานะระบบ Domain</div>
                <div class="card-value $domainBadgeClass" id="disp-domain">$isDomainJoin</div>
            </div>
            <div class="card">
                <div class="card-label">IP Address</div>
                <div class="card-value" id="disp-ip">$ipAddress</div>
            </div>
            <div class="card gw">
                <div class="card-label">Default Gateway</div>
                <div class="card-value" id="disp-gw">$gateway</div>
            </div>
            <div class="card dns">
                <div class="card-label">DNS Server</div>
                <div class="card-value" id="disp-dns">$dnsServers</div>
            </div>
            <div class="card nic">
                <div class="card-label">การ์ดเครือข่ายหลัก</div>
                <div class="card-value" id="disp-nic">$adapterName</div>
            </div>
        </div>

        <div class="action-box">
            <div>
                <strong>ต้องการส่งข้อมูลให้ทีมงาน IT หรือไม่?</strong>
                <div style="font-size: 12px; color: #475569; margin-top: 2px;">กดปุ่มนี้เพื่อคัดลอกข้อมูลสรุป แล้วนำไปวาง (Ctrl+V) ส่งใน LINE ได้ทันที</div>
            </div>
            <button id="copyBtn" class="copy-btn" onclick="copyInfo()">📋 คัดลอกข้อมูลส่งให้ทีม IT</button>
        </div>

        <div class="table-header">
            <div style="font-weight: 600; font-size: 15px; color: #0f172a;">ตารางเส้นทางเครือข่าย (IP Routing Table)</div>
            <input type="text" id="searchInput" class="search-input" placeholder="พิมพ์ค้นหา เช่น 0.0.0.0 หรือ IP..." onkeyup="filterTable()">
        </div>

        <div class="table-box">
            <table id="routeTable">
                <thead>
                    <tr>
                        <th>Destination Prefix (เครือข่ายปลายทาง)</th>
                        <th>Next Hop (ส่งต่อไปยัง IP)</th>
                        <th>Interface (อุปกรณ์)</th>
                        <th>Metric</th>
                    </tr>
                </thead>
                <tbody>
                    $routeRows
                </tbody>
            </table>
        </div>
        <div class="tip">* แถบสีเขียวคือ Default Route (0.0.0.0/0) เส้นทางหลักในการออกสู่อินเทอร์เน็ต</div>

        <div class="cna-footer">
            Script Check Net พัฒนาโดย กอง CNA v. 1.0
        </div>
    </div>

    <script>
        function copyInfo() {
            var comp   = document.getElementById('disp-comp').innerText.trim();
            var domain = document.getElementById('disp-domain').innerText.trim();
            var ip     = document.getElementById('disp-ip').innerText.trim();
            var gw     = document.getElementById('disp-gw').innerText.trim();
            var dns    = document.getElementById('disp-dns').innerText.trim();
            var nic    = document.getElementById('disp-nic').innerText.trim();
            var time   = document.getElementById('disp-time').innerText.trim();
            
            var text = "[ข้อมูลระบบและเครือข่ายเครื่องผู้ใช้งาน]\n" +
                       "- ชื่อเครื่อง (Computer Name): " + comp + "\n" +
                       "- สถานะ Domain: " + domain + "\n" +
                       "- IP Address: " + ip + "\n" +
                       "- Default Gateway: " + gw + "\n" +
                       "- DNS Server: " + dns + "\n" +
                       "- การ์ดเครือข่าย: " + nic + "\n" +
                       "- วันเวลาที่ตรวจสอบ: " + time + "\n" +
                       "- Script Check Net พัฒนาโดย กอง CNA v. 1.0";

            var tempArea = document.createElement("textarea");
            tempArea.value = text;
            tempArea.style.position = "fixed";
            tempArea.style.left = "-9999px";
            tempArea.style.top = "0";
            document.body.appendChild(tempArea);
            tempArea.focus();
            tempArea.select();
            
            var success = false;
            try {
                success = document.execCommand('copy');
            } catch (e) {
                success = false;
            }
            document.body.removeChild(tempArea);

            var btn = document.getElementById('copyBtn');
            if (success) {
                var oldText = btn.innerHTML;
                btn.innerHTML = "✅ คัดลอกสำเร็จแล้ว!";
                btn.classList.add('copied');
                setTimeout(function() {
                    btn.innerHTML = oldText;
                    btn.classList.remove('copied');
                }, 2500);
            } else {
                alert("ไม่สามารถคัดลอกอัตโนมัติได้ กรุณาลองใหม่อีกครั้ง");
            }
        }

        function filterTable() {
            var input = document.getElementById("searchInput").value.toLowerCase();
            var rows = document.getElementById("routeTable").getElementsByTagName("tbody")[0].getElementsByTagName("tr");
            for (var i = 0; i < rows.length; i++) {
                var text = rows[i].innerText.toLowerCase();
                rows[i].style.display = text.includes(input) ? "" : "none";
            }
        }
    </script>
</body>
</html>
"@

# 5. บันทึกและเปิดบนเบราว์เซอร์
$reportPath = "$env:TEMP\cna_network_report.html"
[System.IO.File]::WriteAllText($reportPath, $html, [System.Text.Encoding]::UTF8)
Start-Process $reportPath